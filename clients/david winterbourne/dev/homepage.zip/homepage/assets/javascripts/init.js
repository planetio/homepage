(function() {


  $("body").on("click", "#field-guide-trigger", function() {
    $("#field-guides-checkbox").attr("checked", "checked");
  });


})();